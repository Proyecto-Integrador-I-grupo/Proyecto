import express from "express";
import { body } from "express-validator";
import {
  crearMatricula,
  obtenerMatriculas,
  obtenerGrupos,
  crearGrupo,
  actualizarGrupo,
  eliminarGrupo,
  obtenerDetalleGrupo,
  retirarEstudianteGrupo,
  transferirEstudianteGrupo
} from "../controllers/matriculaProcessController.js";
import { validarCampos } from "../middleware/validationMiddleware.js";
import { requireAuth } from "../middleware/authMiddleware.js";

const router = express.Router();

const validarMatricula = [
  body("fecha").notEmpty().withMessage("La fecha es obligatoria.")
    .isISO8601().withMessage("La fecha no tiene un formato válido."),
  body("periodo").isInt({ min: 1, max: 4 }).withMessage("El período (trimestre) debe ser un número entre 1 y 4."),
  body("anio").isInt({ min: 2000, max: 2100 }).withMessage("El año lectivo no es válido."),
  body("tipo").notEmpty().isLength({ max: 20 }).withMessage("El tipo de matrícula es obligatorio (máx. 20 caracteres)."),
  body("estado").notEmpty().isLength({ max: 20 }).withMessage("El estado de la matrícula es obligatorio (máx. 20 caracteres)."),
  body("observaciones").optional({ nullable: true }).isLength({ max: 20 })
    .withMessage("Las observaciones no pueden superar 20 caracteres (limitación del procedimiento de matrícula)."),
  body("id_estudiante").isInt({ min: 1 }).withMessage("Debe seleccionar un estudiante."),
  body("id_usuario").isInt({ min: 1 }).withMessage("Falta el usuario que procesa la matrícula."),
  body("id_grupo").isInt({ min: 1 }).withMessage("Debe seleccionar un grupo.")
];

const validarGrupo = [
  body("nombre_grupo").trim().notEmpty().withMessage("El nombre del grupo es obligatorio."),
  body("capacidad").isInt({ min: 1 }).withMessage("La capacidad debe ser un número entero mayor a cero."),
  body("id_seccion").isInt({ min: 1 }).withMessage("Debe seleccionar una sección académica.")
];

const validarGrupoUpdate = [
  body("capacidad").isInt({ min: 1 }).withMessage("La capacidad debe ser un número entero mayor a cero.")
];

const validarRetiroEstudiante = [
  body("id_estudiante").isInt({ min: 1 }).withMessage("Debe indicar el estudiante a retirar.")
];

const validarTransferenciaEstudiante = [
  body("fecha").notEmpty().withMessage("La fecha es obligatoria.")
    .isISO8601().withMessage("La fecha no tiene un formato válido."),
  body("periodo").isInt({ min: 1, max: 4 }).withMessage("El período (trimestre) debe ser un número entre 1 y 4."),
  body("anio").isInt({ min: 2000, max: 2100 }).withMessage("El año lectivo no es válido."),
  body("tipo").notEmpty().isLength({ max: 20 }).withMessage("El tipo de matrícula es obligatorio (máx. 20 caracteres)."),
  body("estado").notEmpty().isLength({ max: 20 }).withMessage("El estado de la matrícula es obligatorio (máx. 20 caracteres)."),
  body("observaciones").optional({ nullable: true }).isLength({ max: 20 })
    .withMessage("Las observaciones no pueden superar 20 caracteres (limitación del procedimiento de matrícula)."),
  body("id_estudiante").isInt({ min: 1 }).withMessage("Debe indicar el estudiante."),
  body("id_usuario").isInt({ min: 1 }).withMessage("Falta el usuario que procesa la transferencia."),
  body("id_grupo_actual").isInt({ min: 1 }).withMessage("Debe indicar el grupo de origen."),
  body("id_grupo_nuevo").isInt({ min: 1 }).withMessage("Debe seleccionar el grupo destino.")
];

// Matrícula
router.get("/matricula", requireAuth, obtenerMatriculas);
router.post("/matricula", requireAuth, validarMatricula, validarCampos, crearMatricula);
router.post("/matricula/transferir", requireAuth, validarTransferenciaEstudiante, validarCampos, transferirEstudianteGrupo);

// Grupos
router.get("/grupos", requireAuth, obtenerGrupos);
router.post("/grupos", requireAuth, validarGrupo, validarCampos, crearGrupo);
router.put("/grupos/:id", requireAuth, validarGrupoUpdate, validarCampos, actualizarGrupo);
router.delete("/grupos/:id", eliminarGrupo);
router.get("/grupos/:id/detalle", requireAuth, obtenerDetalleGrupo);
router.put("/grupos/:id/retirar-estudiante", requireAuth, validarRetiroEstudiante, validarCampos, retirarEstudianteGrupo);

export default router;