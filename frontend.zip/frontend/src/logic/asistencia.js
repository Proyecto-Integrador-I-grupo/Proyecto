import {
  apiFetch,
  currentUser,
  showToast
} from './ui.js';

import {
  populateGruposSelects
} from './matricula.js';

(function () {
  const moduleName = 'asistencia';
  window.EduControlModules = window.EduControlModules || {};
  window.EduControlModules[moduleName] = {
    name: moduleName,
    init() {
      const section = document.getElementById(`${moduleName}-view`);
      if (!section) return;
      section.dataset.module = moduleName;
      wireAsistenciaEvents();
    },
    load: loadAsistenciaData
  };

  if (document.readyState !== 'loading') {
    window.dispatchEvent(new CustomEvent('app:module-ready', { detail: { module: moduleName } }));
  }
})();

/* ==========================================
   MÓDULO DE ASISTENCIA 
   ========================================== */

let asistenciaChartInstance = null;

function wireAsistenciaEvents() {
  const asisForm = document.getElementById('asistencia-form');
  if (asisForm && !asisForm.dataset.wired) {
    asisForm.dataset.wired = '1';
    asisForm.addEventListener('submit', handleAsistenciaSubmit);
  }

  const modForm = document.getElementById('modificar-asistencia-form');
  if (modForm && !modForm.dataset.wired) {
    modForm.dataset.wired = '1';
    modForm.addEventListener('submit', handleModificarAsistenciaSubmit);
  }

  const asisGrupoSelEl = document.getElementById('asis-id-grupo');
  if (asisGrupoSelEl && !asisGrupoSelEl.dataset.wired) {
    asisGrupoSelEl.dataset.wired = '1';
    asisGrupoSelEl.addEventListener('change', () => {
      cargarRosterGrupoAsistencia();
    });
  }

  // --- Filtros del historial en cascada ---
  const histGrupoSel = document.getElementById('hist-filtro-grupo');
  if (histGrupoSel && !histGrupoSel.dataset.wired) {
    histGrupoSel.dataset.wired = '1';
    histGrupoSel.addEventListener('change', async () => {
      await poblarFiltroEstudiantesHistorial(histGrupoSel.value);
      cargarHistorialAsistencia();
    });
  }

  const histEstudianteSel = document.getElementById('hist-filtro-estudiante');
  if (histEstudianteSel && !histEstudianteSel.dataset.wired) {
    histEstudianteSel.dataset.wired = '1';
    histEstudianteSel.addEventListener('change', cargarHistorialAsistencia);
  }

  // NUEVO: filtro de Materia/Curso
  const histMateriaSel = document.getElementById('hist-filtro-materia');
  if (histMateriaSel && !histMateriaSel.dataset.wired) {
    histMateriaSel.dataset.wired = '1';
    histMateriaSel.addEventListener('change', cargarHistorialAsistencia);
  }

  const histEstadoSel = document.getElementById('hist-filtro-estado');
  if (histEstadoSel && !histEstadoSel.dataset.wired) {
    histEstadoSel.dataset.wired = '1';
    histEstadoSel.addEventListener('change', cargarHistorialAsistencia);
  }

  const histDesde = document.getElementById('hist-filtro-fecha-desde');
  if (histDesde && !histDesde.dataset.wired) {
    histDesde.dataset.wired = '1';
    histDesde.addEventListener('change', cargarHistorialAsistencia);
  }

  const histHasta = document.getElementById('hist-filtro-fecha-hasta');
  if (histHasta && !histHasta.dataset.wired) {
    histHasta.dataset.wired = '1';
    histHasta.addEventListener('change', cargarHistorialAsistencia);
  }

  const histBusqueda = document.getElementById('hist-filtro-busqueda');
  if (histBusqueda && !histBusqueda.dataset.wired) {
    histBusqueda.dataset.wired = '1';
    let debounceTimer = null;
    histBusqueda.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(cargarHistorialAsistencia, 350);
    });
  }

  const histLimpiar = document.getElementById('hist-limpiar-filtros');
  if (histLimpiar && !histLimpiar.dataset.wired) {
    histLimpiar.dataset.wired = '1';
    histLimpiar.addEventListener('click', async () => {
      if (histGrupoSel) histGrupoSel.value = '';
      await poblarFiltroEstudiantesHistorial('');
      if (histEstudianteSel) histEstudianteSel.value = '';
      if (histMateriaSel) histMateriaSel.value = '';
      if (histEstadoSel) histEstadoSel.value = '';
      if (histDesde) histDesde.value = '';
      if (histHasta) histHasta.value = '';
      if (histBusqueda) histBusqueda.value = '';
      cargarHistorialAsistencia();
    });
  }

  const histRefrescar = document.getElementById('hist-refrescar');
  if (histRefrescar && !histRefrescar.dataset.wired) {
    histRefrescar.dataset.wired = '1';
    histRefrescar.addEventListener('click', cargarHistorialAsistencia);
  }

  const hoyISO = new Date().toISOString().split('T')[0];
  const asisFechaInput = document.getElementById('asis-fecha');
  if (asisFechaInput) { asisFechaInput.max = hoyISO; if (!asisFechaInput.value) asisFechaInput.value = hoyISO; }

  // Asegurar que al abrir el modal de asistencia se recarguen los grupos correctamente y se cargue el roster si ya hay uno seleccionado
  const modalRegistrarAsistenciaEl = document.getElementById('modalRegistrarAsistencia');
  if (modalRegistrarAsistenciaEl && !modalRegistrarAsistenciaEl.dataset.wired) {
    modalRegistrarAsistenciaEl.dataset.wired = '1';
    modalRegistrarAsistenciaEl.addEventListener('show.bs.modal', async () => {
      if (typeof populateGruposSelects === 'function') {
        await populateGruposSelects();
      }
      const grupoSel = document.getElementById('asis-id-grupo');
      if (grupoSel && grupoSel.value) {
        await cargarRosterGrupoAsistencia();
      } else if (grupoSel && grupoSel.options.length > 1) {
        grupoSel.value = grupoSel.options[1].value;
        await cargarRosterGrupoAsistencia();
      }
    });
  }
}

async function loadAsistenciaData() {
  if (typeof populateGruposSelects === 'function') {
    await populateGruposSelects();
  }
  
  // No seleccionar un grupo automáticamente. El usuario lo elige al registrar asistencia.
  poblarFiltroGrupoHistorial();
  await poblarFiltroEstudiantesHistorial('');
  await poblarFiltroMateriaHistorial();
  await cargarHistorialAsistencia();
}

async function cargarRosterGrupoAsistencia() {
  const grupoSel = document.getElementById('asis-id-grupo');
  const personaSel = document.getElementById('asis-persona');
  const profesorSel = document.getElementById('asis-id-profesor');
  const hint = document.getElementById('asis-grupo-hint');
  if (!grupoSel || !personaSel || !profesorSel) return;

  const idGrupo = parseInt(grupoSel.value, 10);
  
  if (!idGrupo || isNaN(idGrupo)) {
    personaSel.innerHTML = '<option value="" disabled selected>Primero selecciona un grupo</option>';
    profesorSel.innerHTML = '<option value="" disabled selected>Primero selecciona un grupo</option>';
    personaSel.disabled = true;
    profesorSel.disabled = true;
    if (hint) {
      hint.textContent = 'Selecciona el grupo para filtrar automáticamente el roster.';
      hint.classList.remove('text-danger');
    }
    return;
  }

  personaSel.innerHTML = '<option value="" disabled selected>Cargando estudiantes...</option>';
  profesorSel.innerHTML = '<option value="" disabled selected>Cargando profesor...</option>';
  personaSel.disabled = true;
  profesorSel.disabled = true;

  try {
    const res = await apiFetch(`/api/procesos/grupos/${idGrupo}/detalle`);
    if (!res.ok) throw new Error('No se pudo cargar el detalle del grupo');
    const detalle = await res.json();

    // Guardia anti-race-condition: si mientras esta petición estaba en
    // vuelo el usuario (o el modal al abrirse) cambió el grupo seleccionado,
    // esta respuesta ya quedó vieja/obsoleta. Se descarta para no pisar
    // con datos del grupo anterior lo que corresponde al grupo actual.
    // Esto es lo que causaba que, por ejemplo, al seleccionar "1-B" se
    // terminara mostrando el profesor y los estudiantes de "1-A".
    const idGrupoActualEnPantalla = parseInt(grupoSel.value, 10);
    if (idGrupoActualEnPantalla !== idGrupo) {
      return;
    }

    // Poblar estudiantes
    personaSel.innerHTML = '<option value="" disabled selected>Seleccionar estudiante</option>';
    const estudiantes = detalle.estudiantes || [];
    estudiantes.forEach((e) => {
      const texto = `${e.nombre ?? ''} ${e.apellido1 ?? ''} ${e.apellido2 ?? ''}`.trim();
      personaSel.add(new Option(texto, e.id_estudiante));
    });
    personaSel.disabled = estudiantes.length === 0;

    // Poblar profesores
    profesorSel.innerHTML = '<option value="" disabled selected>Seleccionar profesor</option>';
    const rolActual = (currentUser?.rol || '').toLowerCase();

    if (rolActual === 'profesor' && currentUser?.id_profesor) {
      // Un profesor únicamente puede registrar asistencia bajo su propio nombre.
      // No usamos la lista que devuelve el detalle del grupo (esa refleja el/los
      // profesor(es) vinculados en grupo_profesor, que puede no coincidir con
      // quien tiene la sesión abierta, p. ej. si hay suplencias).
      profesorSel.innerHTML = '';
      const nombreProfesorActual = `${currentUser.nombre ?? ''} ${currentUser.apellido1 ?? ''}`.trim();
      profesorSel.add(new Option(nombreProfesorActual || 'Profesor actual', currentUser.id_profesor));
      profesorSel.value = currentUser.id_profesor;
      profesorSel.disabled = true;
    } else {
      const profesores = detalle.profesores || [];
      profesores.forEach((p) => {
        const texto = `${p.nombre ?? ''} ${p.apellido1 ?? ''} (${p.materia || 'General'})`.trim();
        profesorSel.add(new Option(texto, p.id_profesor));
      });
      profesorSel.disabled = profesores.length === 0;

      if (profesores.length === 1) {
        profesorSel.value = profesores[0].id_profesor;
      }
    }

    if (hint) {
      if (estudiantes.length === 0) {
        hint.textContent = 'Este grupo no tiene estudiantes matriculados.';
        hint.classList.add('text-danger');
      } else {
        hint.textContent = `Se cargaron ${estudiantes.length} estudiante(s) correctamente.`;
        hint.classList.remove('text-danger');
      }
    }
  } catch (error) {
    console.error('Error cargando roster del grupo', error);
    personaSel.innerHTML = '<option value="" disabled selected>Error al cargar estudiantes</option>';
    profesorSel.innerHTML = '<option value="" disabled selected>Error al cargar profesor</option>';
  }
}

async function poblarFiltroGrupoHistorial() {
  const sel = document.getElementById('hist-filtro-grupo');
  if (!sel) return;

  const valorActual = sel.value;
  sel.innerHTML = '<option value="">Todos los grupos</option>';

  try {
    const res = await apiFetch('/api/procesos/grupos');
    if (!res.ok) return;

    const grupos = await res.json();
    grupos.forEach((g) => {
      const id = g.id_grupo ?? g.id;
      const nombre = g.nombre_grupo ?? `Grupo ${id}`;
      sel.add(new Option(nombre, id));
    });

    if (valorActual && Array.from(sel.options).some(o => String(o.value) === String(valorActual))) {
      sel.value = valorActual;
    }
  } catch (error) {
    console.error('Error cargando grupos para filtro de asistencia', error);
  }
}

async function poblarFiltroEstudiantesHistorial(idGrupo) {
  const sel = document.getElementById('hist-filtro-estudiante');
  if (!sel) return;
  sel.innerHTML = '<option value="">Todos los estudiantes</option>';
  
  if (!idGrupo) {
    sel.disabled = false;
    return;
  }

  try {
    const res = await apiFetch(`/api/procesos/grupos/${idGrupo}/detalle`);
    if (!res.ok) return;
    const detalle = await res.json();
    (detalle.estudiantes || []).forEach((e) => {
      const texto = `${e.nombre ?? ''} ${e.apellido1 ?? ''} ${e.apellido2 ?? ''}`.trim();
      sel.add(new Option(texto, e.id_estudiante));
    });
  } catch (e) {
    console.error('Error cargando estudiantes para filtro', e);
  }
}

/**
 * NUEVO: Puebla el filtro "Materia/Curso" del historial con las materias
 * distintas registradas actualmente en la tabla profesor.
 */
async function poblarFiltroMateriaHistorial() {
  const sel = document.getElementById('hist-filtro-materia');
  if (!sel) return;

  const valorActual = sel.value;
  sel.innerHTML = '<option value="">Todas las materias</option>';

  try {
    const res = await apiFetch('/api/procesos/asistencia');
    if (!res.ok) return;

    const registros = await res.json();
    const materias = [...new Set(
      (Array.isArray(registros) ? registros : [])
        .map(r => String(r.materia_curso ?? r.materia ?? '').trim())
        .filter(Boolean)
    )].sort((a, b) => a.localeCompare(b, 'es'));

    materias.forEach((materia) => sel.add(new Option(materia, materia)));

    if (valorActual && Array.from(sel.options).some(o => o.value === valorActual)) {
      sel.value = valorActual;
    }
  } catch (error) {
    console.error('Error cargando materias para filtro', error);
  }
}

async function cargarHistorialAsistencia() {
  const tbody = document.getElementById('asistencia-historial-body');
  if (!tbody) return;

  const idGrupo = document.getElementById('hist-filtro-grupo')?.value || '';
  const idEstudiante = document.getElementById('hist-filtro-estudiante')?.value || '';
  const materia = document.getElementById('hist-filtro-materia')?.value || '';
  const estado = document.getElementById('hist-filtro-estado')?.value || '';
  const fechaDesde = document.getElementById('hist-filtro-fecha-desde')?.value || '';
  const fechaHasta = document.getElementById('hist-filtro-fecha-hasta')?.value || '';
  const busqueda = document.getElementById('hist-filtro-busqueda')?.value.trim().toLowerCase() || '';

  tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted"><span class="spinner-border spinner-border-sm me-2"></span>Cargando historial...</td></tr>';

  try {
    // Descargamos el historial base y aplicamos los filtros en el cliente.
    // Así los filtros siguen funcionando aunque el backend no reciba todavía
    // todos los parámetros de filtrado.
    const res = await apiFetch('/api/procesos/asistencia');
    if (!res.ok) throw new Error('No se pudo cargar el historial');

    const registros = await res.json();

    const filtrados = (Array.isArray(registros) ? registros : []).filter((r) => {
      const registroGrupo = String(r.id_grupo ?? '');
      const registroEstudiante = String(r.id_estudiante ?? '');
      const registroMateria = String(r.materia_curso ?? r.materia ?? '').trim().toLowerCase();
      const registroEstado = String(r.estado_asistencia ?? '').trim().toLowerCase();
      const registroFecha = r.fecha ? String(r.fecha).split('T')[0] : '';
      const textoBusqueda = [
        r.estudiante_nombre,
        r.estudiante_apellido1,
        r.estudiante_apellido2,
        r.profesor_nombre,
        r.profesor_apellido1,
        r.nombre_grupo,
        r.materia_curso,
        r.materia,
        r.observaciones
      ].filter(Boolean).join(' ').toLowerCase();

      if (idGrupo && registroGrupo !== String(idGrupo)) return false;
      if (idEstudiante && registroEstudiante !== String(idEstudiante)) return false;
      if (materia && registroMateria !== materia.toLowerCase()) return false;
      if (estado && registroEstado !== estado.toLowerCase()) return false;
      if (fechaDesde && (!registroFecha || registroFecha < fechaDesde)) return false;
      if (fechaHasta && (!registroFecha || registroFecha > fechaHasta)) return false;
      if (busqueda && !textoBusqueda.includes(busqueda)) return false;

      return true;
    });

    renderHistorialAsistencia(filtrados);
  } catch (error) {
    console.error('Error cargando historial de asistencia', error);
    tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-danger">Error al cargar el historial.</td></tr>';
    actualizarGraficosAsistencia([]);
  }
}

function renderHistorialAsistencia(registros) {
  const tbody = document.getElementById('asistencia-historial-body');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (!registros.length) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8" class="text-center py-5">
          <i class="bi bi-calendar-x display-6 text-muted d-block mb-2"></i>
          <span class="text-muted">No hay registros de asistencia con estos filtros.</span>
        </td>
      </tr>
    `;
    actualizarGraficosAsistencia([]);
    return;
  }

  const etiquetasEstado = {
    presente: 'Presente',
    ausente: 'Ausente',
    tardia: 'Tardía',
    justificada: 'Justificada'
  };

  registros.forEach((r) => {
    const idAsis = r.id_asistencia ?? r.id;
    const estudiante = `${r.estudiante_nombre ?? ''} ${r.estudiante_apellido1 ?? ''} ${r.estudiante_apellido2 ?? ''}`.trim();
    const profesor = `${r.profesor_nombre ?? ''} ${r.profesor_apellido1 ?? ''}`.trim();
    const materiaCurso = r.materia_curso ?? '-';
    const fecha = r.fecha ? String(r.fecha).split('T')[0] : '-';
    const estado = (r.estado_asistencia || '').toLowerCase();
    const etiqueta = etiquetasEstado[estado] || r.estado_asistencia || '-';
    const observaciones = r.observaciones ? r.observaciones : '—';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${fecha}</td>
      <td class="fw-semibold">${estudiante || '-'}</td>
      <td>${r.nombre_grupo ?? '-'}</td>
      <td>${profesor || '-'}</td>
      <td>${materiaCurso}</td>
      <td><span class="attendance-badge attendance-${estado}">${etiqueta}</span></td>
      <td class="observaciones-cell" title="${observaciones}">${observaciones}</td>
      <td class="text-end">
        <button type="button" class="btn btn-outline-primary btn-sm px-2 py-1 btn-modificar-asistencia" title="Modificar estado">
          <i class="bi bi-pencil-square"></i> Modificar
        </button>
      </td>
    `;
    
    const btnMod = tr.querySelector('.btn-modificar-asistencia');
    btnMod.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      abrirModalModificarAsistencia(idAsis, estudiante, estado, r.observaciones || '');
    });

    tbody.appendChild(tr);
  });

  actualizarGraficosAsistencia(registros);
}

function abrirModalModificarAsistencia(idAsistencia, estudianteNombre, estadoActual, observacionesActuales) {
  document.getElementById('mod-id-asistencia').value = idAsistencia;
  document.getElementById('mod-estudiante-nombre').value = estudianteNombre;
  document.getElementById('mod-estado').value = estadoActual;
  document.getElementById('mod-observaciones').value = observacionesActuales !== '—' ? observacionesActuales : '';
  
  const modalEl = document.getElementById('modalModificarAsistencia');
  if (modalEl) {
    const modal = new bootstrap.Modal(modalEl);
    modal.show();
  }
}

async function handleModificarAsistenciaSubmit(e) {
  e.preventDefault();
  const idAsistencia = document.getElementById('mod-id-asistencia').value;
  const payload = {
    estado_asistencia: document.getElementById('mod-estado').value,
    observaciones: document.getElementById('mod-observaciones').value.trim() || null
  };

  const btn = document.getElementById('mod-submit');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Guardando...'; }

  try {
    const res = await apiFetch(`/api/procesos/asistencia/${idAsistencia}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      showToast('Registro de asistencia actualizado correctamente');
      const modalEl = document.getElementById('modalModificarAsistencia');
      const modal = bootstrap.Modal.getInstance(modalEl);
      if (modal) modal.hide();
      await cargarHistorialAsistencia();
    } else {
      const err = await res.json().catch(() => ({}));
      showToast(err.mensaje || err.error || 'No se pudo actualizar el registro', 'error');
    }
  } catch (e) {
    showToast('Error de conexión al actualizar asistencia', 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="bi bi-save"></i> Actualizar Registro'; }
  }
}

function actualizarGraficosAsistencia(registros) {
  const total = registros.length;
  const presentes = registros.filter((r) => (r.estado_asistencia || '').toLowerCase() === 'presente').length;
  const ausentes = registros.filter((r) => (r.estado_asistencia || '').toLowerCase() === 'ausente').length;
  const tardias = registros.filter((r) => (r.estado_asistencia || '').toLowerCase() === 'tardia').length;
  const justificadas = registros.filter((r) => (r.estado_asistencia || '').toLowerCase() === 'justificada').length;

  const elTotal = document.getElementById('graf-total');
  const elEfectiva = document.getElementById('graf-efectiva');
  const elAusentismo = document.getElementById('graf-ausentismo');

  if (elTotal) elTotal.textContent = total;
  const ef = total > 0 ? ((presentes / total) * 100).toFixed(1) : 0;
  const aus = total > 0 ? ((ausentes / total) * 100).toFixed(1) : 0;
  if (elEfectiva) elEfectiva.textContent = `${ef}%`;
  if (elAusentismo) elAusentismo.textContent = `${aus}%`;

  const ctx = document.getElementById('chartAsistenciaEstados');
  if (!ctx) return;

  if (asistenciaChartInstance) {
    asistenciaChartInstance.destroy();
  }

  if (typeof Chart !== 'undefined') {
    asistenciaChartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Presentes', 'Ausentes', 'Tardías', 'Justificadas'],
        datasets: [{
          data: [presentes, ausentes, tardias, justificadas],
          backgroundColor: ['#22c55e', '#ef4444', '#f59e0b', '#3b82f6'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { boxWidth: 12, font: { size: 11 } }
          }
        }
      }
    });
  }
}

async function handleAsistenciaSubmit(e) {
  e.preventDefault();
  const grupoSel = document.getElementById('asis-id-grupo');
  const personaSel = document.getElementById('asis-persona');
  const profesorSel = document.getElementById('asis-id-profesor');

  if (!grupoSel.value || !personaSel.value || !profesorSel.value) {
    showToast('Selecciona grupo, estudiante y profesor.', 'error');
    return;
  }

  const payload = {
    fecha: document.getElementById('asis-fecha').value,
    estado_asistencia: document.getElementById('asis-estado').value,
    observaciones: document.getElementById('asis-observaciones').value.trim() || null,
    id_estudiante: parseInt(personaSel.value, 10),
    id_grupo: parseInt(grupoSel.value, 10),
    id_profesor: parseInt(profesorSel.value, 10)
  };

  const submitBtn = document.getElementById('asis-submit');
  if (submitBtn) { submitBtn.disabled = true; submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Guardando...'; }

  try {
    const res = await apiFetch('/api/procesos/asistencia', { 
      method: 'POST', 
      headers: { 'Content-Type': 'application/json' }, 
      body: JSON.stringify(payload) 
    });
    
    if (res.ok) {
      showToast('Asistencia guardada correctamente');
      document.getElementById('asis-observaciones').value = '';
      personaSel.value = '';
      await cargarHistorialAsistencia();
    } else {
      const json = await res.json().catch(() => ({}));
      showToast(json.error || json.mensaje || 'Error guardando asistencia', 'error');
    }
  } catch {
    showToast('Error guardando asistencia', 'error');
  } finally {
    if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = '<i class="bi bi-check2-circle"></i> Guardar Registro de Asistencia'; }
  }
}